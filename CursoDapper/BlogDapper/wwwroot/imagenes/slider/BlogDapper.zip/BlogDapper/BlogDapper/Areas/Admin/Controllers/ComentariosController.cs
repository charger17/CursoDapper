﻿using BlogDapper.Models;
using BlogDapper.Repositorio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BlogDapper.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ComentariosController : Controller
    {
        private readonly IComentarioRepositorio _repoComentario;

        public ComentariosController(IComentarioRepositorio repoComentario)
        {
            _repoComentario = repoComentario;
        }

        [HttpGet]
        public IActionResult Index()
        {   
            return View();
        }

        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Crear([Bind("IdCategoria, Nombre, FechaCreacion")] Categoria categoria)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _repoCategoria.CrearCategoria(categoria);
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(categoria);
        //}

        //[HttpGet]
        //public IActionResult Editar(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var categoria = _repoCategoria.GetCategoria(id.GetValueOrDefault());
        //    if (categoria == null)
        //    {
        //        return NotFound();
        //    }           

        //    return View(categoria);
        //}


        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Editar(int id, [Bind("IdCategoria, Nombre, FechaCreacion")] Categoria categoria)
        //{
        //    if (id != categoria.IdCategoria)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        _repoCategoria.ActualizarCategoria(categoria);
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(categoria);
        //}


        #region
        [HttpGet]
        public IActionResult GetComentarios()
        {
            return Json(new { data = _repoComentario.GetComentarioArticulo()});
        }

        [HttpDelete]
        public IActionResult BorrarComentario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            else
            {
                _repoComentario.BorrarComentario(id.GetValueOrDefault());
                return Json(new { success = true, message = "Comentario borrado correctamente" });
            }
        }
        #endregion
    }
}
